"""

"""
import logging

converter_logger = logging.getLogger("pydub.converter")

def log_conversion(conversion_command):
    converter_logger.debug("subprocess.call(%s)", repr(conversion_command))